import '../App.css';

function Header() {
    return (
        <header className="header">
            <div>
                <span>Nikita Kobik, P3224</span>
                <span>variant 412346</span>
            </div>
        </header>
    );
}

export default Header;
